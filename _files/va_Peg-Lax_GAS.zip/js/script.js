var popup = document.getElementById('popup');

function menuClick(e, id) {
    'use strict';
    e.className = 'menu clicked';
    window.parent.navigateToSequence(id, 'animation');
}

function popupOpen() {
    'use strict';
    popup.className = 'aberto';
}

function popupClose() {
    'use strict';
    popup.className = '';
}